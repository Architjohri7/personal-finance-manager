package com.syfe.pfm;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PersonalFinanceManagerApplicationTests {

    @Test
    void applicationContextLoads() {
        assertTrue(true);
    }
}